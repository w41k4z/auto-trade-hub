// import Unsplash from "unsplash-js";

// const APP_ACCESS_KEY: string = "";
// const APP_SECRET: string = "";

// export const unsplash = new Unsplash({
//   accessKey: APP_ACCESS_KEY,
//   secret: APP_SECRET,
// });

export {};