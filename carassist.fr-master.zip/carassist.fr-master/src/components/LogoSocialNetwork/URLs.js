export const fbURL = 'https://fr-fr.facebook.com/CarAssistParis/'
export const instaURL = 'https://www.instagram.com/garage_car_assist/'
