import './SimpleSider.css'

function SimpleSider({params}) {
    return (
        <div id="simpleSider">
            <h1>{params}</h1>
        </div>
    )
}

export default SimpleSider;